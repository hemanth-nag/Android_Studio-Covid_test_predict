package com.example.covid1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Main2Activity extends AppCompatActivity {
    float points=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
    public void yes(View v){
        points= points+1;
        Intent goToNext = new Intent();
        goToNext.setClass(this, Main3Activity.class);
        goToNext.putExtra("points", points);
        startActivity(goToNext);
        finish();
    }
    public void no(View v){
        Intent goToNext = new Intent();
        goToNext.setClass(this, Main3Activity.class);
        goToNext.putExtra("points", points);
        startActivity(goToNext);
        finish();
    }
}
