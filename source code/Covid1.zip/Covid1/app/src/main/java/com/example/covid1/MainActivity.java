package com.example.covid1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void next(View v){
        Intent goToNext = new Intent();
        goToNext.setClass(this, Main2Activity.class);
        startActivity(goToNext);
    }
    public void webpage1(View v) {
        Intent goToweb = new Intent();
        goToweb.setClass(this, Main15Activity.class);
        startActivity(goToweb);
    }
    public void devinfo(View v){
        Intent goTodevinfo = new Intent();
        goTodevinfo.setClass(this, Main16Activity.class);
        startActivity(goTodevinfo);
    }
}
