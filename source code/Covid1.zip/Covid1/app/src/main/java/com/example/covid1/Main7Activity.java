package com.example.covid1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Main7Activity extends AppCompatActivity {
    float points;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        Intent caller = getIntent();
        points = caller.getFloatExtra("points",0);
    }
    public void yes(View v){
        points= points+1;
        Intent goToNext = new Intent();
        goToNext.setClass(this, Main8Activity.class);
        goToNext.putExtra("points", points);
        startActivity(goToNext);
        finish();
    }
    public void no(View v){
        Intent goToNext = new Intent();
        goToNext.setClass(this, Main8Activity.class);
        goToNext.putExtra("points", points);
        startActivity(goToNext);
        finish();
    }
}
