package com.example.covid1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Main5Activity extends AppCompatActivity {
    float points;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        Intent caller = getIntent();
        points = caller.getFloatExtra("points",0);
    }
    public void yes(View v){
        points= points+1;
        Intent goToNext = new Intent();
        goToNext.setClass(this, Main6Activity.class);
        goToNext.putExtra("points", points);
        startActivity(goToNext);
        finish();
    }
    public void no(View v){
        Intent goToNext = new Intent();
        goToNext.setClass(this, Main6Activity.class);
        goToNext.putExtra("points", points);
        startActivity(goToNext);
        finish();
    }
}
