package com.example.covid1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main14Activity extends AppCompatActivity {
    float points;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main14);
        Intent caller = getIntent();
        points = caller.getFloatExtra("points",0);
        TextView textView5=(TextView) findViewById(R.id.textView5);
        if (points<=2)
            textView5.setText("May be due to stress, nothing COVID-19 related. Continue to observe.");
        else if(points>2 && points<=5)
            textView5.setText("Hydrate properly and maintain personal hygiene. Re-evaluate after 2 days");
        else if(points>5 && points<=12)
            textView5.setText("Seek a consultation with a Doctor at the earliest.");
        else
            textView5.setText("You might be COVID-19 +ve. Self isolate and call: +91-11-23978046");
    }
    public void testimage(View v){
        Intent goToNext = new Intent();
        goToNext.setClass(this, Main17Activity.class);
        startActivity(goToNext);
    }
public void homescreen(View v){
    Intent goToNext = new Intent();
    goToNext.setClass(this, MainActivity.class);
    startActivity(goToNext);
    finish();
}

}
